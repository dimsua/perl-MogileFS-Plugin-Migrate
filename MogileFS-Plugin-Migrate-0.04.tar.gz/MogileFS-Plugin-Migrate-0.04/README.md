MogileFS::Plugin::Migrate
=========================

MogileFS::Plugin::Migrate is a MogileFS plugin for moving files across domains.

### License

This work is licensed under the [Perl License](http://dev.perl.org/licenses/).
